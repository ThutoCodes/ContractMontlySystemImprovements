﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using WebApplication3.Models; // Import your models

namespace WebApplication3.Data // Ensure the namespace is correct
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        

        }

        // DbSet for your Claim model
        public DbSet<Claim> Claims { get; set; }
    }
}