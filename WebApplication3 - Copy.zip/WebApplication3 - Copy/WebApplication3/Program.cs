using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using WebApplication3.Models;
using WebApplication3.Data;
using WebApplication3;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddControllersWithViews();
builder.Services.AddSignalR(); // Add this line for SignalR


// Register ApplicationDbContext with Dependency Injection
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Build the app
var app = builder.Build();

// Configure the HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapHub<ClaimHub>("/ClaimHub");
// Configure default route
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Lecturer}/{action=SubmitClaim}/{id?}");

// Run the app
app.Run();
