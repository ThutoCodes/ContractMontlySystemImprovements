﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication3.Data; // Ensure the correct namespace
using WebApplication3.Models; // Import your models
using System.Threading.Tasks; // Import for async/await

namespace WebApplication3.Controllers
{
    public class ClaimsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ClaimsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // POST: Approve a claim
        [HttpPost]
        public async Task<IActionResult> Approve(int id)
        {  
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null)
            {
                TempData["Error"] = "Claim not found.";
                return RedirectToAction("Dashboard");
            }

            claim.Status = ClaimStatus.Approved; // Use enum
            await _context.SaveChangesAsync();

            TempData["Success"] = "Claim approved successfully.";
            return RedirectToAction("Dashboard");
        }

        // POST: Reject a claim
        [HttpPost]
        public async Task<IActionResult> Reject(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null)
            {
                TempData["Error"] = "Claim not found.";
                return RedirectToAction("Dashboard");
            }

            claim.Status = ClaimStatus.Rejected; // Use enum
            await _context.SaveChangesAsync();

            TempData["Success"] = "Claim rejected successfully.";
            return RedirectToAction("Dashboard");
        }
    }
}