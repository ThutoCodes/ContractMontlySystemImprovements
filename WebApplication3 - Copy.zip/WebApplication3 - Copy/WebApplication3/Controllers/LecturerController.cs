﻿using Microsoft.AspNetCore.Mvc;
using WebApplication3.Models;
namespace WebApplication3.Controllers
{
    public class LecturerController : Controller
    {
        // Temporary in-memory list to store claims (for demo purposes)
        private static List<Claim> claims = new List<Claim>();

        // GET: Lecturer Dashboard
        public IActionResult Dashboard()
        {
            return View(claims); // Pass the list of claims to the view
        }

        // GET: Form to Submit a New Claim
        public IActionResult SubmitClaim()
        {
            return View(); // Render the claim submission form
        }

        // POST: Handle Claim Submission      
        [HttpPost]
        public IActionResult SubmitClaim(Claim claim, IFormFile SupportingDocument)
        {

            try
            {


                if (ModelState.IsValid)
                {
                    // Validate file upload
                    if (SupportingDocument != null && SupportingDocument.Length > 0)
                    {
                        var allowedExtensions = new[] { ".pdf", ".docx", ".jpg", ".png" };
                        var fileExtension = Path.GetExtension(SupportingDocument.FileName);

                        if (!allowedExtensions.Contains(fileExtension.ToLower()))
                        {
                            ModelState.AddModelError("SupportingDocument", "Only PDF, DOCX, JPG, and PNG files are allowed.");
                            return View(claim);
                        }

                        if (SupportingDocument.Length > 5 * 1024 * 1024) // 5MB limit
                        {
                            ModelState.AddModelError("SupportingDocument", "File size cannot exceed 5MB.");
                            return View(claim);
                        }

                        // Save file
                        var uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                        Directory.CreateDirectory(uploadsFolder);

                        var uniqueFileName = Guid.NewGuid().ToString() + "_" + Path.GetFileName(SupportingDocument.FileName);
                        var filePath = Path.Combine(uploadsFolder, uniqueFileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            SupportingDocument.CopyTo(stream);
                        }

                        claim.SupportingDocument = "/uploads/" + uniqueFileName;
                    }

                    claim.SubmissionDate = DateTime.Now;
                    claim.Status = ClaimStatus.Pending; // Set initial status
                    claims.Add(claim); // Store claim in in-memory list

                    return RedirectToAction("Dashboard");
                }
            }
            catch (Exception ex) {
                Console.WriteLine($"Error occurred: {ex.Message}");
                ModelState.AddModelError("", "An error occurred while processing your request. Please try again.");
            }

            return View(claim); // Re-display form on validation errors
            }
            
        // New View: View Pending Claims for Coordinators/Managers
        public IActionResult ManageClaims()
        {
            var pendingClaims = claims.Where(c => c.Status == ClaimStatus.Pending).ToList();
            return View(pendingClaims); // Pass only pending claims to the view
        }

        public IActionResult Approve(int id)
        {
            var claim = claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim == null)
            {
                TempData["Error"] = "Claim not found.";
                return RedirectToAction("ManageClaims");
            }

            claim.Status = ClaimStatus.Approved;

            // Broadcast status change via SignalR (Optional)
            // NotifyStatusChange(claim.ClaimId, claim.Status);

            return RedirectToAction("ManageClaims");
        }

        public IActionResult Reject(int id)
        {
            var claim = claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim == null)
            {
                TempData["Error"] = "Claim not found.";
                return RedirectToAction("ManageClaims");
            }

            claim.Status = ClaimStatus.Rejected;

            // Broadcast status change via SignalR (Optional)
            // NotifyStatusChange(claim.ClaimId, claim.Status);

            return RedirectToAction("ManageClaims");
        }
    }
}

    

  