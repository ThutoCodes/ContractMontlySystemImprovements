﻿using Microsoft.AspNetCore.SignalR;

namespace WebApplication3
{
    public class ClaimHub:Hub
    {

        public async Task SendClaimUpdate(string message)
        {
            await Clients.All.SendAsync("ReceiveClaimUpdate", message);
        }
    }
}
