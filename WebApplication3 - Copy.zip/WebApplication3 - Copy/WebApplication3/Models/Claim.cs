﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication3.Models
{
    public enum ClaimStatus
    {
        Pending,
        Approved,
        Rejected
    }

    public class Claim
        {



            public int ClaimId { get; set; }


        [Required(ErrorMessage = "Lecturer Name is required.")]
        public string LecturerName { get; set; }
        [Required(ErrorMessage = "Module is required.")]

        public string Module { get; set; }
        [Required(ErrorMessage = "Hours Worked is required.")]

        public int HoursWorked { get; set; }
        [Required(ErrorMessage = "Hourly Rate is required.")]

        public decimal HourlyRate { get; set; }

            public DateTime SubmissionDate { get; set; }

            public string? SupportingDocument { get; set; }

            public string? AdditionalNotes { get; set; }

        public ClaimStatus Status { get; set; } // Use the enum for status
    }
}

